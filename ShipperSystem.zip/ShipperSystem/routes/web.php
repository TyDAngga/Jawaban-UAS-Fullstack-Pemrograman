<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/kurir', [ProfileController::class, 'edit'])->name('kurir.edit');
    Route::patch('/kurir', [ProfileController::class, 'update'])->name('kurir.update');
    Route::delete('/kurir', [ProfileController::class, 'destroy'])->name('kurir.destroy');

    Route::resource('PengirimanController', PostController::class);
	 	Route::get('/pengiriman', [ProfileController::class, 'edit'])->name('pengiriman.edit');
    Route::patch('/pengiriman', [ProfileController::class, 'update'])->name('pengiriman.update');
    Route::delete('/pengiriman', [ProfileController::class, 'destroy'])->name('pengiriman.destroy');
    
		Route::resource('BarangController', PostController::class);
	 	Route::get('/barang', [ProfileController::class, 'edit'])->name('barang.edit');
    Route::patch('/barang', [ProfileController::class, 'update'])->name('barang.update');
    Route::delete('/barang', [ProfileController::class, 'destroy'])->name('barang.destroy');

		Route::get('/totaltransaction', [ProfileController::class, 'edit'])->name('profile.edit');

    Route::resource('pengiriman', PostController::class);
});

require __DIR__.'/auth.php';
